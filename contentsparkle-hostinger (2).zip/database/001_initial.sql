-- Only for a new EMPTY external PostgreSQL database. No runtime/startup DDL.
-- Existing Replit data and Clerk users are not transferred by this script.
BEGIN;
CREATE TABLE accounts (
  id text PRIMARY KEY,
  credits integer NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX project_owner_idx ON projects(user_id);
CREATE TABLE brand_voices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL,
  tone text NOT NULL,
  audience text NOT NULL,
  avoid text NOT NULL DEFAULT '',
  approved_facts text NOT NULL DEFAULT '',
  sample text NOT NULL DEFAULT ''
);
CREATE INDEX voice_owner_idx ON brand_voices(user_id);
CREATE TABLE documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  project_id uuid REFERENCES projects(id) ON DELETE SET NULL,
  title text NOT NULL,
  content text NOT NULL DEFAULT '',
  tool_type text NOT NULL DEFAULT 'studio',
  language text NOT NULL DEFAULT 'English',
  favorite boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX document_owner_idx ON documents(user_id, updated_at);
CREATE TABLE generation_requests (
  id uuid PRIMARY KEY,
  user_id text NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  input_hash text NOT NULL,
  tool_type text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  document_id uuid REFERENCES documents(id) ON DELETE SET NULL,
  words integer NOT NULL DEFAULT 0,
  input_tokens integer NOT NULL DEFAULT 0,
  output_tokens integer NOT NULL DEFAULT 0,
  model text NOT NULL,
  prompt_version text NOT NULL DEFAULT '1',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX generation_owner_idx ON generation_requests(user_id, created_at);
CREATE TABLE credit_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  request_id uuid REFERENCES generation_requests(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  kind text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ledger_request_kind_idx ON credit_ledger(request_id, kind);
COMMIT;
