import { access } from "node:fs/promises";
for (const file of ["server.js", "server/index.mjs", "public/index.html", "database/001_initial.sql"]) {
  await access(new URL(`./${file}`, import.meta.url));
}
console.log("Prebuilt ContentSparkle package verified. Startup: node server.js");
