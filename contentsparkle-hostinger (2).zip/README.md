# ContentSparkle — Hostinger Node.js upload package

This is a **prebuilt, full-stack Express application**. The compiled website
and API are included. No Replit workspace, pnpm workspace, Vite dev server,
Docker, PHP conversion or separate frontend site is required on Hostinger.

## Upload in hPanel

1. Choose **Websites → Add Website → Node.js web app → Upload your files**.
2. Upload `contentsparkle-hostinger.zip` as the project archive.
3. Review settings (override auto-detection if it chooses React/static):

| Setting | Value |
| --- | --- |
| Framework | **Express** |
| Node.js | **24** |
| Package manager | **npm** |
| Root directory | `/` (or empty) |
| Build script | `build` (`npm run build`) |
| Entry file | **`server.js`** |
| Output directory | **Leave empty** — this is a server app |
| Start command, if requested | `npm start` |

`package.json` is at the ZIP root, not inside another folder. The build command
checks the prebuilt files. It does not rebuild the original TypeScript source.
Use the original Replit project and `pnpm hostinger:package` to make an updated ZIP.

Do not upload only `public/` or deploy this as a static React site: doing so
removes the API, authentication checks, persistence and AI generation.
Hostinger generates routing rules; do not add a custom `.htaccess`.

## Required environment variables

Enter these in the app's **Environment Variables** section before deployment.
Never send secret keys in chat or commit them to Git.

| Name | Where it comes from |
| --- | --- |
| `DATABASE_URL` | An externally reachable PostgreSQL connection string |
| `CLERK_PUBLISHABLE_KEY` | Publishable key from your production Clerk application |
| `CLERK_SECRET_KEY` | Matching server secret from that same Clerk application |
| `OPENAI_API_KEY` | Your own OpenAI API key with billing/access enabled |
| `NODE_ENV` | `production` |

Hostinger supplies the listening port. The server uses its `PORT` and binds to
`0.0.0.0`. If manually starting elsewhere, the default is 3000.

The browser obtains **only** the public Clerk key from `/runtime-config.js`.
Do not add `VITE_OPENAI_API_KEY` or expose the database/Clerk secret in frontend
configuration. Key updates in hPanel require restarting/redeploying the app but
do not require rebuilding its frontend.

### Authentication setup

Use a Clerk application configured for your actual Hostinger domain, including
its production DNS and sign-in provider requirements. Frontend paths are
`/sign-in` and `/sign-up`; OAuth callbacks below those paths are served correctly.
Use matching keys from the **same** Clerk environment.

This portable package uses Clerk's standard frontend endpoint, not Replit's
managed production proxy. Do not set `VITE_CLERK_PROXY_URL` for this package.
The current Replit-managed tenant is not exported or deleted. Provisioning an
independent Clerk application creates a separate user directory; existing users
and their saved documents are **not automatically migrated**. Do not point a new
user directory at an old populated database without a deliberate identity/data
migration plan.

### AI setup

The Hostinger package uses your own OpenAI key and OpenAI billing. Replit's
managed AI proxy credentials are not bundled and are not used by this package.
The configured model is `gpt-5.4-mini`; ensure your account can access it.
Without `OPENAI_API_KEY`, browsing and manual editing remain available, while
AI generation is explicitly disabled without consuming credits.

### Database setup — important

This app requires **PostgreSQL**, not MySQL/MariaDB and not MongoDB.
Use a PostgreSQL service reachable from Hostinger, with the provider-required
TLS parameters in the connection string. Do not disable certificate verification.
Hostinger's Supabase frontend URL/anonymous key are not a substitute for the
PostgreSQL `DATABASE_URL` used by this server.

For a NEW EMPTY database, run `database/001_initial.sql` once in that database's
SQL console. Alternatively, in a trusted environment with Node and npm:

```
npm install
# Set DATABASE_URL securely in your shell/environment, then:
npm run db:initialize -- --confirm-empty-database
```

The initialization command refuses databases containing public tables. Schema
creation never runs during web-server startup, install or build. The SQL script
is a one-time empty-database baseline, **not** an update migration for an existing
site. Back up any populated database before planning schema or data migration.
No existing Replit accounts, documents, credits or private data are in this ZIP.

## Package contents

- `package.json` — standard npm app detection, build/start commands
- `server.js` — Hostinger's entry point and safe configuration validation
- `server/` — compiled API, static hosting and logging workers
- `public/` — compiled website assets
- `database/001_initial.sql` — initial PostgreSQL schema
- `initialize-database.mjs` — optional guarded empty-database initializer
- `.env.example` — variable names only, no credentials

## Verify after deploying

- `/` and a direct `/tools` refresh show the app.
- `/api/healthz` returns `{"status":"ok"}`.
- `/api/tools` returns 50 tools.
- `/api/documents` without a session returns 401.
- `/runtime-config.js` contains only your public Clerk key, no secrets.
- Sign up, generate once, edit/save, reload and export a document.
- Verify HTTPS, Clerk production domains and email/OAuth callbacks.

The package has been built and smoke-tested locally; it has **not** been
deployed to your Hostinger account. Real Hostinger credentials, domain DNS,
database access and production sign-in must be configured and tested there.
This remains the current beta, without paid subscriptions or team features.

## Troubleshooting

- **Hostinger only shows static output settings:** select Express rather than
  React/Vite and use `server.js` as entry, with no output directory.
- **Missing configuration on startup:** add the named variables in hPanel;
  never upload an actual `.env` with the archive.
- **Health works but documents fail:** check PostgreSQL connectivity and apply
  the initial schema to an empty database.
- **Sign-in fails:** check matching Clerk keys, domain/DNS/provider configuration
  and HTTPS. Development users do not become production users automatically.
- **AI disabled:** add your own OpenAI key, enable provider billing and restart.
- **Updating:** upload a newly generated ZIP using the app's redeploy workflow;
  keep the same database and auth directory unless intentionally migrating.

Official Hostinger references:
- https://docs.hostinger.com/node.js/creating-an-app
- https://docs.hostinger.com/node.js/build-settings
