// Hostinger entry file. This deployment contains compiled code; no pnpm
// workspace, Replit proxy or development server is needed on the host.
process.env.NODE_ENV = "production";
process.env.CONTENTSPARKLE_HOSTING = "hostinger";
const required = ["DATABASE_URL", "CLERK_PUBLISHABLE_KEY", "CLERK_SECRET_KEY"];
const missing = required.filter(name => !process.env[name]);
if (missing.length) {
  console.error(`Configure these environment variables in Hostinger hPanel: ${missing.join(", ")}`);
  process.exit(1);
}
if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is missing: browsing and editing work, but AI generation is disabled.");
}
await import("./server/index.mjs");
