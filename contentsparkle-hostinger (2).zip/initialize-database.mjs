import pg from "pg";
import { readFile } from "node:fs/promises";

if (process.argv[2] !== "--confirm-empty-database") {
  console.error("This command initializes a NEW, EMPTY PostgreSQL database. It does not transfer existing accounts or documents.");
  console.error("After confirming the target is empty, run: npm run db:initialize -- --confirm-empty-database");
  process.exit(1);
}
if (!process.env.DATABASE_URL) throw new Error("Set DATABASE_URL securely before initializing the database.");
const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
try {
  await client.connect();
  const existing = await client.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'");
  if (existing.rows.length) throw new Error("Database is not empty. Initialization stopped without changes.");
  await client.query(await readFile(new URL("./database/001_initial.sql", import.meta.url), "utf8"));
  console.log("ContentSparkle schema initialized. No existing data was migrated.");
} catch (error) {
  // Never log a connection string, SQL contents, or arbitrary provider errors.
  console.error(error instanceof Error && error.message === "Database is not empty. Initialization stopped without changes."
    ? error.message
    : "Database initialization failed. Check connectivity, permissions and the empty-database requirement.");
  process.exitCode = 1;
} finally {
  await client.end();
}
